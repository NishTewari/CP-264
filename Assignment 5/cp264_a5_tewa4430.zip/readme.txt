Name: Nishant Tewari 
ID: 190684430
Email: tewa4430@mylaurier.ca
WorkID: CP264-a5
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols: A - assignment, Q - question 
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If marker gives different evaluation value say 1, it will show 
[2/2/1] in the marking report. 

Evaluation grid: [self-evaluation/total/marker-evaluation]

A5

Q1 Record data by linked list
Q1.1 structure design                     [2/2/*]
Q1.2 search()                             [2/2/*]
Q1.3 insert()                             [2/2/*]
Q1.4 delete()                             [2/2/*]
Q1.5 clean()                              [2/2/*]

Q2 Doubly linked list
Q2.1 structure design                     [2/2/*]
Q2.2 new_node(),clean()                   [2/2/*]
Q2.3 display_forward(),display_backward() [2/2/*]
Q2.4 insert_start(),insert_end()          [2/2/*]
Q2.5 delete_start(),delete_end()          [2/2/*]

Q3 Big integer type
Q3.1 BIGINT structure                     [2/2/*]
Q3.2 add()                                [4/4/*]
Q3.3 Fibonacci()                          [4/4/*]

Total:                                   [30/30/*]

Copy and paste the console output of your public test in the following. This will help markers to evaluate your program if it fails the testing.  

Q1 output:
Ali,88.0
Allison,67.7
Bodnar,93.6
Chabot,80.4
Costa,45.1
Dabu,74.4
Eccles,77.8
Giblett,59.1
Hatch,66.5
He,85.7
Koreck,77.4
Lamont,98.1
Myrie,76.7
Parr,92.5
Pereira,80.3
Peters,82.3
Smith,60.1
Suglio,85.7
Sun,67.7
Wang,98.1
Moore:92.0
Wang:not fount
count:20
mean:77.6
stddev:13.1
start:0


Q2 output:


Q3 output:
