#ifndef MYSTRING_H
#define MYSTRING_H

int str_length(char*);
int word_count(char*);
void lower_case(char*);
void trim(char*);

#endif
